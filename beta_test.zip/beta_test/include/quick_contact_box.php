                    <div class="row quick-contact-box hide show-med">
                        <ul class="col-12 row social-contact">
                            <li>
                                <a href="http://www.behance.com/theliquidcharcoal" target="_blank">
                                    <img src="img/svg/quick_contact_box/qc_behance.svg" alt="Liquidcharcoal on Behance">
                                </a>
                            </li>
                            <li>
                                <a href="http://www.twitter.com/liquidcharcoal" target="_blank">
                                    <img src="img/svg/quick_contact_box/qc_twitter.svg" alt="Liquidcharcoal on Twitter">
                                </a>
                            </li>
                            <li>
                                <a href="http://www.fb.com/liquidcharcoal" target="_blank">
                                    <img src="img/svg/quick_contact_box/qc_fb.svg" alt="Liquidcharcoal on Facebook">
                                </a>
                            </li>
                            <li>
                                <a href="http://www.linkedin.com/in/liquidcharcoal" target="_blank">
                                    <img src="img/svg/quick_contact_box/qc_linkedin.svg" alt="Liquidcharcoal on LinkedIN">
                                </a>
                            </li>   
                        </ul>
                        <ul class="direct-contact row col-12">
                            <li>
                                <a href="tel:+17325939577">
                                    <img src="img/svg/quick_contact_box/qc_tel.svg" alt="+17325939577">
                                </a>
                            </li>
                            <li>
                                <a href="mailto:hello@liquidcharcoal.com">
                                    <img src="img/svg/quick_contact_box/qc_mail.svg" alt="hello@liquidcharcoal.com">
                                </a>
                            </li>
                        </ul>
                    </div>