<input type="checkbox" name="" id="nav-box" class="nav-toggle">

<label for="nav-box" class="nav-toggle-label">
    <span class="ham"></span>
</label>
<nav>
    <ul class="nav-lg">
        <li>
            <a href="index.php" class="active">Home</a>
        </li>
        <li>
            <a href="about.php">About</a>
        </li>
        <li>
            <a href="resume.php">Resume</a>
        </li>
        <li>
            <a href="portfolio.php">Portfolio</a>
        </li>
        <li>
            <a href="contact_lc.php">Contact</a>
        </li>
    </ul>
</nav>