<?php
    header( 'Location: site/coming_soon.html' ) ;
?>